
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);
			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload: function(){

		game.load.image('ball', 'assets/images/ball.png');
		game.load.image('hoop', 'assets/images/hoop.png');
		game.load.image('side rim', 'assets/images/side_rim.png');
		game.load.image('front rim', 'assets/images/front_rim.png');
		game.load.image('pauseButton','assets/images/paused.png');

		game.load.image('win0', 'assets/images/win0.png');
		game.load.image('win1', 'assets/images/win1.png');
		game.load.image('win2', 'assets/images/win2.png');
		game.load.image('win3', 'assets/images/win3.png');
		game.load.image('win4', 'assets/images/win4.png');
		game.load.image('lose0', 'assets/images/lose0.png');
		game.load.image('lose1', 'assets/images/lose1.png');
		game.load.image('lose2', 'assets/images/lose2.png');
		game.load.image('lose3', 'assets/images/lose3.png');
		game.load.image('lose4', 'assets/images/lose4.png');
		game.load.image('menu2', 'assets/images/menu2.png');
		game.load.image('gg', 'assets/images/gg.png');
		game.load.image('1', 'assets/images/1.png');
		game.load.image('about2', 'assets/images/aboutt.png');
		game.load.spritesheet("about","assets/images/about.png",226,0);
		


		game.load.audio('score', 'assets/audio/score.wav');
		game.load.audio('backboard', 'assets/audio/backboard.wav');
		game.load.audio('whoosh', 'assets/audio/whoosh.wav');
		game.load.audio('fail', 'assets/audio/fail.wav');
		game.load.audio('spawn', 'assets/audio/spawn.wav');

	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
		game.scale.forcePortrait = true;
		game.scale.forceLandscape = false;
		game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

		//game.stage.backgroundColor = "#DCDCDC";
		 home = game.add.image(0,0,'1');
		 home.scale.set(1.0);
		 pbtn = game.add.button(w/2,370,"gg",this.lundag);
		 pbtn.anchor.set(0.5);
		pbtn.scale.x = 1.0;
		pbtn.scale.y = 1.0;
		aboutButton = game.add.button(80,480,'about',this.aboutOnClick, this);
		
    	
		// menuText = game.add.text(w/2,h/2, "Menu", {"fill":"red"});
  //       menuText.anchor.setTo(0.5,0.5);
		// menuText.scale.x = 1.3;
		// menuText.scale.y = 1.3;

		 //playText = game.add.text(w/2,350, "Play", {"fill":"blue"});
  //       playText.anchor.setTo(0.5,0.5);
		 //playText.scale.x = 1.3;
		 //playText.scale.y = 1.3;
		
		//console.log("current state: menu");

	},
	update:function(){
			if(keyboard.up.isDown){
				game.state.start("playGame");
			}
	},
	 lundag:function (){
	game.state.start("playGame");
	},
	 aboutOnClick: function(){
            aboutpage=game.add.image(0,0,"about2");
            restartButton=game.add.button(250,5,"menu2",restartB,this);
            function restartB() {
            aboutpage.visible =! restartButton.visible;
            restartButton.destroy();

            game.state.start("menuGame");
            // window.location.href=window.location.href
            }
        }

	 
}

playGame = {

	create: function(){

		game.physics.startSystem(Phaser.Physics.P2JS);
		game.physics.p2.setImpactEvents(true);
		game.physics.p2.gravity.y = 0;

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
		game.scale.forcePortrait = true;
		game.scale.forceLandscape = false;
		game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();
		

		collisionGroup = game.physics.p2.createCollisionGroup();

		score_sound = game.add.audio('score');
		backboard = game.add.audio('backboard');
		backboard.volume = 0.5;
		whoosh = game.add.audio('whoosh');
		fail = game.add.audio('fail');
		fail.volume = 0.1;
		spawn = game.add.audio('spawn');

		

		game.stage.backgroundColor = "#0000ff";

		
		current_score_text = game.add.text(187, 312, '', { font: 'Arial', fontSize: '40px', fill: '#000', align: 'center' }); // 300, 500
		current_best_text = game.add.text(143, 281, '', { font: 'Arial', fontSize: '20px', fill: '#000', align: 'center' });// 230, 450
		current_best_score_text = game.add.text(187, 312, '', { font: 'Arial', fontSize: '40px', fill: '#00e6e6', align: 'center' }); // 300, 500

		hoop = game.add.sprite(160, 120, 'hoop'); 
		hoop.scale.x = 0.3; 
		hoop.scale.y = 0.4;
		

		this.createBall();
		

		cursors = game.input.keyboard.createCursorKeys();

		game.input.onDown.add(this.click, this);
		game.input.onUp.add(this.release, this);
		labelhi = game.add.text(30, 20, "High: " +this.getScore(),{font: '20px Arial', fill: '#black'});
		this.pauseButton = this.game.add.sprite(290,25, 'pauseButton');
		this.pauseButton.inputEnabled = true;
		this.pauseButton.events.onInputUp.add(function () {
		this.game.paused = true;
		var style = {font: '45px Showcard Gothic', fill: 'red'};
		text = game.add.text(game.width * 1.2, game.height * 1.2, "Paused", style);
		text.anchor.set(0.5, 0.5);
		}, this);
		game.input.onDown.add(function () {
		if (this.game.paused) {
		this.game.paused = false;
		text.destroy();
		}       
		}, this);


		

		

	},
	update: function(){
	
		
		
	if (ball && ball.body.velocity.y > 0) {
		front_rim = game.add.sprite(167, 175, 'front rim');
		front_rim.scale.x = 0.4;
		ball.body.collides([collisionGroup], this.hitRim, this);
	}

	if (ball && ball.body.velocity.y > 0 && ball.body.y > 188 && !ball.isBelowHoop) {
		ball.isBelowHoop = true;
		ball.body.collideWorldBounds = false;
		var rand = Math.floor(Math.random() * 5);
		if (ball.body.x > 183 && ball.body.x < 250) {
			emojiName = "win" + rand;
			
			current_score += 1;
			current_score_text.text = current_score;
			if (this.getScore()<=current_score){
				this.saveScore(current_score);
				labelhi.text = "Best: "+current_score;
	}
			score_sound.play();
		} else {
			emojiName = "lose" + rand;
			fail.play();
			if (current_score > this.getScore) {
			this.getScore = current_score;
			
			}
			current_score = 0;
			current_score_text.text = '';
			current_best_text.text = 'Current Best';
			current_best_score_text.text = +this.getScore();
		}
		emoji = game.add.sprite(170, 100, emojiName);
		emoji.scale.setTo(0.25, 0.25);
		moveInTween = game.add.tween(emoji).from( { y: 150 }, 500, Phaser.Easing.Elastic.Out, true);
		fadeInTween = game.add.tween(emoji).from( { alpha: 0 }, 200, Phaser.Easing.Linear.None, true, 0, 0, false);
		moveInTween.onComplete.add(this.tweenOut, this);

	}

	if (ball && ball.body.y > 1200) {
		game.physics.p2.gravity.y = 0;
		ball.kill();
		this.createBall();
	}

	},
		tweenOut: function() {
			moveOutTween = game.add.tween(emoji).to( { y: 50 }, 600, Phaser.Easing.Elastic.In, true);
			moveOutTween.onComplete.add(function() { emoji.kill(); }, this);
			setTimeout(function () {
				fadeOutTween = game.add.tween(emoji).to( { alpha: 0 }, 300, Phaser.Easing.Linear.None, true, 0, 0, false);
			}, 450);
		},

		hitRim: function() {

			backboard.play();
		},
		
		createBall: function() {

			var xpos;
			if (current_score === 0) {
				xpos = 200;
			} else {
				xpos = 60 + Math.random() * 280;
			}
			spawn.play();
			ball = game.add.sprite(xpos, 547, 'ball');
			ball.scale.x = 1.6;
			ball.scale.y = 1.6;
			game.add.tween(ball.scale).from({x : 1.5, y : 1.5}, 100, Phaser.Easing.Linear.None, true, 0, 0, false);
			game.physics.p2.enable(ball, false);
			ball.body.setCircle(60); 
			ball.launched = false;
			ball.isBelowHoop = false;
		},

		click:function(pointer) {

			var bodies = game.physics.p2.hitTest(pointer.position, [ ball.body ]);
			if (bodies.length) {
				start_location = [pointer.x, pointer.y];
				isDown = true;
				location_interval = setInterval(function () {
					start_location = [pointer.x, pointer.y];
				}.bind(this), 200);
			}
		},

		release:function(pointer) {

			if (isDown) {
				window.clearInterval(location_interval);
				isDown = false;
				end_location = [pointer.x, pointer.y];

				if (end_location[1] < start_location[1]) {
					var slope = [end_location[0] - start_location[0], end_location[1] - start_location[1]];
					var x_traj = -500 * slope[0] / slope[1];
					this.launch(x_traj);
				}
			}
		},

		launch:function(x_traj) {

			if (ball.launched === false) {
				ball.body.setCircle(36);
				ball.body.setCollisionGroup(collisionGroup);
				current_best_text.text = '';
				current_best_score_text.text = '';
				ball.launched = true;
				game.physics.p2.gravity.y = 3000;
				game.add.tween(ball.scale).to({x : 1.5, y : 1.5}, 500, Phaser.Easing.Linear.None, true, 0, 0, false);
				ball.body.velocity.x = x_traj;
				ball.body.velocity.y = -1750;
				ball.body.rotateRight(x_traj / 3);
				whoosh.play();
			}
		},
		saveScore:function(score){
			localStorage.setItem("gamedata",score);
		},

		getScore: function(){
		return (localStorage.getItem("gamedata") == null || localStorage.getItem("gamedata") == "")?0:
		localStorage.getItem("gamedata");
		},
};		

winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}

loseGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}
